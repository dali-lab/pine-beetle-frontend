Contents of SPB.southwide.Weekly.2011-2017_v07.zip

SPB.southwide.Weekly.2011-2017.DATA.v07.xlsx	Data and metadata in Excel format
SPB.southwide.Weekly.2011-2017.DATA.v07.csv	Data in csv format
SPB.southwide.Weekly.2011-2017.metadata.xlsx	Metadata in pdf format