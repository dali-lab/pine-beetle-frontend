Contents of SPB.southwide.Weekly.1987-2011.v04.zip

SPB.southwide.Weekly.1987-2011.DATA.v04.xlsx	Data and metadata in Excel format
SPB.southwide.Weekly.1987-2011.DATA.v04.csv	Data in csv format
SPB.southwide.Weekly.1987-2011.metadata.xlsx	Metadata in pdf format